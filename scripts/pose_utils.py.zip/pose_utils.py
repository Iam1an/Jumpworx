# Temporary shim to avoid code drift. All logic now lives in jwcore.pose_utils.
# TODO: remove this file after callers migrate to 'from jwcore.pose_utils import ...'
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))  # ensure 'jwcore' is importable when running as a script
from jwcore.pose_utils import *  # noqa: F401,F403
